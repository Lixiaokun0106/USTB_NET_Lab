# Internal and external network communication
